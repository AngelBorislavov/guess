#!/usr/bin/env python3

import random
number = random.randint(1,10)
gsg = int(input("You have 3 lives to guess the right number betwen 1 and 10 : "))
lives = 2

while gsg != number and lives !=0:
	lives = lives - 1
	if gsg < number:
		gsg = int(input(f'Yoy have {lives + 1} lives ,try hight num : '))
	
	if gsg > number:
		gsg = int(input(f'Yoy have {lives + 1} lives ,try low num : '))
	
	if lives == 0 and gsg!= number: 
		print(f'game over the number was {number}')
		break
if gsg == number:
	print('you win')

	
	
